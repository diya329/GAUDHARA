# GauDhara — Dairy Mastitis Screening & Herd Health Platform

> **Hackyard Build 2026** · Production-grade veterinary dairy health platform integrating multi-parametric milk sensors, Nodus Compute cloud workloads, and Supabase persistent authentication.

---

## Overview

GauDhara solves a multi-billion dollar problem in global dairy production: **subclinical bovine mastitis**. Subclinical mastitis causes internal udder epithelial inflammation and reduced milk yield without visible clots or swelling, remaining undetected by traditional visual checks until irreversible tissue damage occurs.

GauDhara monitors:
1. **Four-Quarter Electrical Conductivity (EC)**: Detects unilateral tight-junction damage through inter-quarter disparity ratios ($\ge 1.15\times$).
2. **Somatic Cell Count (SCC) Proxy**: Leukocyte immune mobilization index.
3. **ISFET Potentiometric pH**: Detects alkaline blood serum leakage or acidic coliform fermentation.
4. **Nodus Cloud Compute**: High-performance containerized execution engine running deterministic physiological workloads.
5. **Supabase Auth & Database**: Herd persistence with Row Level Security (RLS) and branded email templates.

---

## Design System

Crafted according to agritech and veterinary standards:
- **Primary Color**: Deep Forest Green (`#143D2B`, `#1B4332`)
- **Secondary Accent**: Muted Sage Green (`#4E6B5D`, `#87A996`)
- **Surfaces**: Crisp Off-White & Clean Slate (`#F8F9F8`, `#FFFFFF`, `#F1F4F2`)
- **Text**: Deep Charcoal (`#0F172A`, `#19231D`, `#475569`)
- **Status Colors**: Restrained Emerald Green (Normal), Amber (Subclinical Suspect), Crimson (Clinical Alert)
- **Zero-Pill Discipline**: Clean typographic separators, unboxed metadata, crisp rectangular and subtle rounded cards.

---

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Configure Environment
Copy `.env.example` to `.env`:
```bash
cp .env.example .env
```
Populate your keys:
- `VITE_SUPABASE_URL`: Your Supabase Project URL
- `VITE_SUPABASE_ANON_KEY`: Your Supabase Public Anon Key
- `NODUS_API_KEY`: Your Nodus Compute API Key (Server-side)

*(Note: If no keys are provided, GauDhara immediately runs in full-featured Demo Mode with built-in realistic herd profiles and a local deterministic verification engine).*

### 3. Start Development Server
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## Verification & Testing

### Python Workload Unit Tests
```bash
python3 -m unittest backend/tests/test_screening.py
```

### TypeScript Lint Check
```bash
npm run lint
```

### Production Build
```bash
npm run build
```

---

## Documentation

- [SUPABASE_SETUP.md](./SUPABASE_SETUP.md) — Step-by-step email template setup and custom domain roadmap.
- [NODUS_COMPUTE_INTEGRATION.md](./NODUS_COMPUTE_INTEGRATION.md) — Architecture and benchmarks for Nodus Compute.
- `supabase/schema.sql` — PostgreSQL DDL with Row Level Security.
- `supabase/email_templates/` — Production-ready HTML email templates.
