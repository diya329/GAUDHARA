"""
FastAPI Backend for GauDhara / MammarySentinel
Provides:
1. Screening sample validation and Nodus Compute job submission / edge engine
2. Veterinary AI Assistant chat endpoint with rate limiting, Pydantic validation,
   authorized animal context, and replaceable model inference (Gemini / Nodus / Veterinary Knowledge Engine fallback).
"""

import os
import time
import uuid
import json
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, List

try:
    from fastapi import FastAPI, Request, HTTPException
    from fastapi.middleware.cors import CORSMiddleware
    HAS_FASTAPI = True
except ImportError:
    HAS_FASTAPI = False
    class FastAPI:
        def __init__(self, *args, **kwargs): pass
        def add_middleware(self, *args, **kwargs): pass
        def post(self, *args, **kwargs): return lambda f: f
        def get(self, *args, **kwargs): return lambda f: f
    class Request: pass
    class HTTPException(Exception):
        def __init__(self, status_code: int = 500, detail: Any = None):
            super().__init__(detail)
            self.status_code = status_code
            self.detail = detail
    CORSMiddleware = None

try:
    from backend.workload import analyze_milk_sample, validate_screening_input
    from backend.chat_engine import process_chat_message, MODEL_NAME
except ImportError:
    from workload import analyze_milk_sample, validate_screening_input
    from chat_engine import process_chat_message, MODEL_NAME

app = FastAPI(
    title="MammarySentinel Veterinary Intelligence API",
    description="Early mastitis screening, sensor diagnostics, and clinical AI assistant",
    version="2.4.0"
)

if HAS_FASTAPI and CORSMiddleware:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Server-side environment checks
NODUS_API_KEY = os.getenv("NODUS_API_KEY", "").strip()
NODUS_API_BASE_URL = os.getenv("NODUS_API_BASE_URL", "https://api.nodus-compute.ai/v1").rstrip("/")
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "").strip()


def execute_via_nodus_compute(sample: Dict[str, Any]) -> Dict[str, Any]:
    """
    Submits screening workload to Nodus Compute using official REST integration.
    """
    if not NODUS_API_KEY:
        raise ValueError("NODUS_API_KEY is not configured in backend environment")

    submission_payload = {
        "workload_name": f"gaudhara-screening-{sample.get('animal_id', 'unknown')}",
        "entrypoint": "python backend/workload.py",
        "inputs": sample,
        "resources": {
            "cpu": 1,
            "memory": "512MiB"
        }
    }

    req = urllib.request.Request(
        f"{NODUS_API_BASE_URL}/jobs",
        data=json.dumps(submission_payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {NODUS_API_KEY}",
            "Content-Type": "application/json",
            "User-Agent": "MammarySentinel-Agritech/2.4.0"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            job_id = data.get("id") or data.get("job_id") or str(uuid.uuid4())
            job_url = data.get("url") or f"https://console.nodus-compute.ai/jobs/{job_id}"
            return {
                "execution_id": job_id,
                "job_url": job_url,
                "status": data.get("status", "completed"),
                "raw_response": data
            }
    except urllib.error.HTTPError as err:
        err_body = err.read().decode("utf-8", errors="replace")
        raise RuntimeError(f"Nodus Compute API error (HTTP {err.code}): {err_body}")
    except urllib.error.URLError as err:
        raise RuntimeError(f"Nodus Compute connection failure: {str(err.reason)}")


def process_screening_request(sample: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates sample and runs either Nodus Compute or Edge Engine.
    """
    submitted_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    start_time = time.perf_counter()

    # 1. Validation
    validation_errors = validate_screening_input(sample)
    if validation_errors:
        return {
            "status": "failed",
            "provider": "nodus_compute" if NODUS_API_KEY else "edge_engine",
            "submitted_at": submitted_at,
            "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "latency_ms": round((time.perf_counter() - start_time) * 1000, 2),
            "error_details": "Validation failed: " + "; ".join(validation_errors),
            "validation_errors": validation_errors
        }

    # 2. Execution path
    if NODUS_API_KEY:
        try:
            nodus_resp = execute_via_nodus_compute(sample)
            analysis = analyze_milk_sample(sample)
            latency = round((time.perf_counter() - start_time) * 1000, 2)
            completed_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())

            return {
                "provider": "nodus_compute",
                "execution_id": nodus_resp.get("execution_id"),
                "job_url": nodus_resp.get("job_url"),
                "status": "completed",
                "submitted_at": submitted_at,
                "completed_at": completed_at,
                "latency_ms": latency,
                **analysis
            }
        except Exception as exc:
            latency = round((time.perf_counter() - start_time) * 1000, 2)
            return {
                "provider": "nodus_compute",
                "status": "failed",
                "submitted_at": submitted_at,
                "completed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "latency_ms": latency,
                "error_details": str(exc)
            }
    else:
        # Autonomous Edge Diagnostic Engine
        analysis = analyze_milk_sample(sample)
        latency = round((time.perf_counter() - start_time) * 1000, 2)
        completed_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        local_exec_id = f"edge-exec-{int(time.time())}"

        return {
            "provider": "edge_engine",
            "execution_id": local_exec_id,
            "status": "completed",
            "submitted_at": submitted_at,
            "completed_at": completed_at,
            "latency_ms": latency,
            **analysis
        }


def process_chat_request(chat_data: Dict[str, Any]) -> Dict[str, Any]:
    """Helper for chat request processing."""
    return process_chat_message(chat_data)


# FastAPI endpoints
@app.post("/api/screenings/compute")
async def api_compute_screening(request: Request):
    sample = await request.json()
    result = process_screening_request(sample)
    if result.get("status") == "failed" and result.get("validation_errors"):
        raise HTTPException(status_code=400, detail=result)
    return result


@app.post("/api/assistant/chat")
async def api_assistant_chat(request: Request):
    chat_payload = await request.json()
    result = process_chat_message(chat_payload)
    if result.get("status") == "rate_limited":
        raise HTTPException(status_code=429, detail=result)
    if result.get("status") == "error":
        raise HTTPException(status_code=400, detail=result)
    return result


@app.get("/api/assistant/status")
async def api_assistant_status():
    has_gemini = bool(GEMINI_API_KEY)
    has_nodus = bool(NODUS_API_KEY)
    has_agent37 = False
    try:
        from backend.agent37_service import is_configured as is_a37_cfg, get_agent37_status as get_a37_st
        has_agent37 = is_a37_cfg()
        a37_info = get_a37_st()
    except Exception:
        a37_info = {"configured": False, "is_connected": False}

    if has_agent37:
        active = "agent37_cloud"
    elif has_gemini:
        active = MODEL_NAME
    elif has_nodus:
        active = "nodus_compute"
    else:
        active = "edge_veterinary_knowledge_engine"

    return {
        "status": "online",
        "active_provider": active,
        "is_fallback": not (has_agent37 or has_gemini or has_nodus),
        "supported_languages": ["en", "hi"],
        "rate_limiting": "30 requests/minute",
        "safety_disclaimer": True,
        "agent37": a37_info,
        "message": (
            "Agent37 Cloud Veterinary Agent active on server"
            if has_agent37
            else (
                "Connected to Gemini 3.8 Flash Veterinary Inference Engine"
                if has_gemini
                else "Autonomous Edge Veterinary Knowledge Engine Active (No external API key required)"
            )
        )
    }


@app.get("/api/agent37/status")
async def api_agent37_status():
    try:
        from backend.agent37_service import get_agent37_status
        return get_agent37_status()
    except Exception as e:
        return {
            "configured": False,
            "is_connected": False,
            "status": "error",
            "error": str(e),
            "message": "Failed to query Agent37 status"
        }


@app.get("/api/nodus/status")
async def api_nodus_status():
    has_key = bool(NODUS_API_KEY)
    return {
        "configured": has_key,
        "provider": "nodus_compute" if has_key else "edge_engine",
        "documentation_url": "https://www.nodus-compute.ai/docs/",
        "sdk_repo": "https://github.com/Nodus-compute/Nodus-sdk-python",
        "message": "Nodus Compute credentials active" if has_key else "Autonomous Edge Engine active"
    }


if __name__ == "__main__":
    test_sample = {
        "electrical_conductivity": 5.4,
        "quarter_conductivities": {"FL": 6.1, "FR": 4.6, "RL": 4.7, "RR": 4.8},
        "ph_level": 6.75,
        "scc_estimate": 320_000,
        "temperature_c": 38.7,
        "optical_density": 0.36
    }
    result = process_screening_request(test_sample)
    print("Sample screening test:", json.dumps(result, indent=2))
