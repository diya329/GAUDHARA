"""
Agent37 Cloud API Service for GauDhara
Provides official integration with Agent37 Cloud API (https://www.agent37.com/docs):
- Instance provisioning and reuse (avoids paid duplicate instances per turn)
- Health polling and readiness check (/v1/health with X-Agent37-Key)
- Multi-turn conversation sessions (/v1/responses with session_id)
- Grounded prompt construction with authorized herd screening context
- Strict veterinary safety guardrails and error handling
"""

import os
import time
import json
import urllib.request
import urllib.error
from typing import Dict, Any, Optional, Tuple

AGENT37_API_BASE = os.getenv("AGENT37_API_BASE", "https://api.agent37.com/v1").rstrip("/")
AGENT37_API_KEY = os.getenv("AGENT37_API_KEY", "").strip()

# Optional pre-configured instance
CONFIGURED_INSTANCE_URL = os.getenv("AGENT37_INSTANCE_URL", "").strip().rstrip("/")
CONFIGURED_INSTANCE_ID = os.getenv("AGENT37_INSTANCE_ID", "").strip()

# Instance Cache to reuse instances across requests
_cached_instance: Dict[str, Any] = {
    "id": CONFIGURED_INSTANCE_ID or None,
    "url": CONFIGURED_INSTANCE_URL or None,
    "last_checked": 0,
    "is_healthy": False
}

DEFAULT_TIMEOUT = 30  # seconds


class Agent37Error(Exception):
    """Custom exception for Agent37 Cloud API errors."""
    def __init__(self, message: str, status_code: Optional[int] = None, error_code: Optional[str] = None):
        super().__init__(message)
        self.status_code = status_code
        self.error_code = error_code


def is_configured() -> bool:
    """Returns True if AGENT37_API_KEY is present in environment."""
    return bool(AGENT37_API_KEY and len(AGENT37_API_KEY) > 0)


def check_instance_health(instance_url: str, timeout: int = 5) -> bool:
    """
    Checks /v1/health on the Agent37 instance URL.
    Header: X-Agent37-Key: $AGENT37_API_KEY
    """
    if not instance_url or not AGENT37_API_KEY:
        return False

    url = f"{instance_url.rstrip('/')}/v1/health"
    req = urllib.request.Request(
        url,
        headers={
            "X-Agent37-Key": AGENT37_API_KEY,
            "User-Agent": "GauDhara-Agritech/2.4.0"
        },
        method="GET"
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            return bool(data.get("healthy") is True or data.get("ok") is True)
    except Exception:
        return False


def get_or_create_instance() -> Tuple[str, str]:
    """
    Retrieves or creates an Agent37 instance.
    Reuses existing healthy instance to prevent spinning up duplicate paid instances.
    Returns (instance_id, instance_url).
    """
    if not is_configured():
        raise Agent37Error("AGENT37_API_KEY is not configured in backend environment", status_code=401)

    now = time.time()

    # 1. Check cached instance first
    if _cached_instance.get("url"):
        # Re-verify health if more than 60 seconds old
        if now - _cached_instance["last_checked"] < 60 and _cached_instance["is_healthy"]:
            return _cached_instance["id"] or "preconfigured", _cached_instance["url"]

        if check_instance_health(_cached_instance["url"]):
            _cached_instance["last_checked"] = now
            _cached_instance["is_healthy"] = True
            return _cached_instance["id"] or "preconfigured", _cached_instance["url"]

    # 2. Query existing instances to reuse before creating a new one
    try:
        list_req = urllib.request.Request(
            f"{AGENT37_API_BASE}/instances",
            headers={
                "Authorization": f"Bearer {AGENT37_API_KEY}",
                "User-Agent": "GauDhara-Agritech/2.4.0"
            },
            method="GET"
        )
        with urllib.request.urlopen(list_req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            instances = data.get("data", []) if isinstance(data, dict) else (data if isinstance(data, list) else [])
            for inst in instances:
                if inst.get("template") in ["agent37-hermes", "hermes"] and inst.get("status") in ["running", "ready"]:
                    inst_id = inst.get("id")
                    inst_url = inst.get("url") or f"https://{inst_id}.agent37.app"
                    if check_instance_health(inst_url):
                        _cached_instance["id"] = inst_id
                        _cached_instance["url"] = inst_url
                        _cached_instance["last_checked"] = now
                        _cached_instance["is_healthy"] = True
                        return inst_id, inst_url
    except Exception as e:
        print(f"[Agent37] Notice querying instances: {e}")

    # 3. Create a new instance via POST /v1/instances with budget
    create_payload = {
        "template": "agent37-hermes",
        "budget": {
            "credit_micros": 1000000  # $1 budget ceiling
        }
    }

    create_req = urllib.request.Request(
        f"{AGENT37_API_BASE}/instances",
        data=json.dumps(create_payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {AGENT37_API_KEY}",
            "Content-Type": "application/json",
            "User-Agent": "GauDhara-Agritech/2.4.0"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(create_req, timeout=15) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            inst_id = result.get("id")
            inst_url = result.get("url") or f"https://{inst_id}.agent37.app"

            # Wait briefly for instance startup
            deadline = time.time() + 30
            while time.time() < deadline:
                if check_instance_health(inst_url, timeout=3):
                    break
                time.sleep(2)

            _cached_instance["id"] = inst_id
            _cached_instance["url"] = inst_url
            _cached_instance["last_checked"] = time.time()
            _cached_instance["is_healthy"] = True
            return inst_id, inst_url

    except urllib.error.HTTPError as err:
        err_body = err.read().decode("utf-8", errors="replace")
        if err.code == 401:
            raise Agent37Error("Invalid AGENT37_API_KEY provided to Agent37 Cloud API.", status_code=401)
        if err.code == 402:
            raise Agent37Error(f"Agent37 wallet balance or instance budget exhausted: {err_body}", status_code=402)
        raise Agent37Error(f"Agent37 instance creation failed (HTTP {err.code}): {err_body}", status_code=err.code)
    except urllib.error.URLError as err:
        raise Agent37Error(f"Connection failure to Agent37 Cloud API: {err.reason}")


def build_system_instructions(authorized_context: Optional[str] = None, language: str = "en") -> str:
    """
    Constructs safety and domain instructions for the Agent37 agent.
    Enforces strict veterinary boundaries:
    - Explains recorded screening measurements and existing risk classifications
    - Recommends follow-up screening and veterinary consultation
    - Never invents 7-14 day forecast or claims unvalidated predictive models
    - Never modifies records, prescribes medications, or issues unapproved alerts
    """
    lang_note = "Respond in Hindi (हिन्दी) where requested." if language == "hi" else "Respond in English."

    return (
        "You are the GauDhara Veterinary AI Assistant on Agent37 Cloud, specialized in bovine mastitis risk screening.\n"
        "STRICT CLINICAL SAFETY RULES:\n"
        "1. GROUNDING: Only reference real sensor screening data provided in context. Never fabricate animal measurements, SCC counts, or citations.\n"
        "2. PRE-CLINICAL NATURE: GauDhara is an early screening aid, NOT a confirmed veterinary diagnosis. Always state this distinction.\n"
        "3. NO UNVALIDATED FORECASTS: Never invent a 7–14-day prediction or claim to be a validated prognostic model.\n"
        "4. NO UNAUTHORIZED ACTIONS: You cannot independently prescribe medication, modify medical records, or delete farm data.\n"
        "5. EMERGENCY TRIAGE: If user mentions severe signs (fever >39.5°C, swollen hot hard quarter, clots/blood in milk, anorexia, or recumbency), immediately advise contacting a licensed veterinarian.\n"
        f"6. LANGUAGE: {lang_note}\n\n"
        f"VERIFIED AUTHORIZED ANIMAL & HERD RECORDS:\n{authorized_context or 'No specific animal attached. Answer general mastitis screening queries.'}\n"
    )


def send_agent_message(
    message: str,
    session_id: Optional[str] = None,
    authorized_context: Optional[str] = None,
    language: str = "en",
    timeout: int = DEFAULT_TIMEOUT
) -> Dict[str, Any]:
    """
    Sends message turn to Agent37 via POST {instance_url}/v1/responses.
    Reuses session_id for multi-turn threads.
    """
    if not is_configured():
        return {
            "status": "disconnected",
            "reply": "Agent37 Cloud API is not configured. Please set AGENT37_API_KEY in the backend environment to enable Agent37 inference.",
            "provider": "agent37_cloud",
            "is_connected": False,
            "session_id": session_id,
            "error": "missing_credentials"
        }

    try:
        inst_id, inst_url = get_or_create_instance()
    except Agent37Error as ae:
        return {
            "status": "error",
            "reply": f"Agent37 instance unavailable: {str(ae)}",
            "provider": "agent37_cloud",
            "is_connected": False,
            "session_id": session_id,
            "error": str(ae)
        }

    # For the first turn in a thread, inject the system instructions
    final_input = message
    if not session_id:
        system_prefix = build_system_instructions(authorized_context, language)
        final_input = f"{system_prefix}\n\nUser Question:\n{message}"
    elif authorized_context:
        final_input = f"[Updated Authorized Context: {authorized_context}]\n\n{message}"

    payload = {
        "input": final_input,
        "stream": False,
        "mode": "chat"
    }
    if session_id:
        payload["session_id"] = session_id

    req_url = f"{inst_url.rstrip('/')}/v1/responses"
    req = urllib.request.Request(
        req_url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "X-Agent37-Key": AGENT37_API_KEY,
            "Content-Type": "application/json",
            "User-Agent": "GauDhara-Agritech/2.4.0"
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            output_text = data.get("output_text") or ""
            ret_session_id = data.get("session_id") or session_id
            turn_status = data.get("status", "completed")
            err_obj = data.get("error")

            if turn_status == "failed" or err_obj:
                err_msg = err_obj.get("message") if isinstance(err_obj, dict) else str(err_obj)
                return {
                    "status": "failed",
                    "reply": f"Agent37 turn error: {err_msg or 'Execution failure'}",
                    "provider": "agent37_cloud",
                    "instance_id": inst_id,
                    "session_id": ret_session_id,
                    "is_connected": True,
                    "error": err_msg
                }

            return {
                "status": "success",
                "reply": output_text.strip(),
                "provider": "agent37_cloud",
                "instance_id": inst_id,
                "session_id": ret_session_id,
                "is_connected": True,
                "raw_response": {
                    "id": data.get("id"),
                    "status": turn_status,
                    "usage": data.get("usage")
                }
            }

    except urllib.error.HTTPError as err:
        err_body = err.read().decode("utf-8", errors="replace")
        return {
            "status": "error",
            "reply": f"Agent37 request failed (HTTP {err.code}): {err_body}",
            "provider": "agent37_cloud",
            "instance_id": inst_id,
            "session_id": session_id,
            "is_connected": False,
            "error": f"HTTP {err.code}: {err_body}"
        }
    except urllib.error.URLError as err:
        return {
            "status": "timeout_or_network_error",
            "reply": f"Agent37 network timeout or connection failure: {err.reason}",
            "provider": "agent37_cloud",
            "instance_id": inst_id,
            "session_id": session_id,
            "is_connected": False,
            "error": str(err.reason)
        }


def get_agent37_status() -> Dict[str, Any]:
    """
    Returns diagnostic connectivity status for Agent37 Cloud.
    """
    configured = is_configured()
    if not configured:
        return {
            "configured": False,
            "is_connected": False,
            "status": "unconfigured",
            "instance_id": None,
            "instance_url": None,
            "provider": "agent37_cloud",
            "message": "AGENT37_API_KEY is not configured in backend environment."
        }

    # If instance cached, check live health
    inst_url = _cached_instance.get("url") or CONFIGURED_INSTANCE_URL
    is_healthy = False
    if inst_url:
        is_healthy = check_instance_health(inst_url, timeout=4)

    return {
        "configured": True,
        "is_connected": is_healthy,
        "status": "connected" if is_healthy else "ready_for_dispatch",
        "instance_id": _cached_instance.get("id"),
        "instance_url": _cached_instance.get("url"),
        "provider": "agent37_cloud",
        "message": (
            "Agent37 Cloud Hermes Agent connected and healthy."
            if is_healthy
            else "Agent37 credentials active. Instance will initialize on first query."
        )
    }
