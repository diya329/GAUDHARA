"""
Automated validation and smoke tests for GauDhara screening analysis.
Covers:
- Valid healthy sample
- Unilateral quarter conductivity disparity (>1.15x)
- Severe clinical multi-parametric mastitis
- Invalid physical values (negative SCC, absurd pH)
- Edge case handling
"""

import unittest
from backend.workload import analyze_milk_sample, validate_screening_input


class TestScreeningWorkload(unittest.TestCase):

    def test_healthy_sample(self):
        sample = {
            "electrical_conductivity": 4.5,
            "quarter_conductivities": {"FL": 4.5, "FR": 4.4, "RL": 4.6, "RR": 4.5},
            "ph_level": 6.65,
            "scc_estimate": 120_000,
            "temperature_c": 38.6,
            "optical_density": 0.28
        }
        errors = validate_screening_input(sample)
        self.assertEqual(len(errors), 0)

        result = analyze_milk_sample(sample)
        self.assertEqual(result["risk_level"], "healthy")
        self.assertLess(result["risk_score"], 25)
        self.assertLess(result["max_quarter_differential_ratio"], 1.15)
        self.assertEqual(len(result["affected_quarters"]), 0)

    def test_unilateral_subclinical_quarter_disparity(self):
        # FL is elevated at 5.9 mS/cm while FR is normal at 4.6 mS/cm (ratio = 1.28x)
        sample = {
            "electrical_conductivity": 5.2,
            "quarter_conductivities": {"FL": 5.9, "FR": 4.6, "RL": 4.7, "RR": 4.6},
            "ph_level": 6.72,
            "scc_estimate": 280_000,
            "temperature_c": 38.8,
            "optical_density": 0.35
        }
        result = analyze_milk_sample(sample)
        self.assertIn("subclinical_suspect", [result["risk_level"], "clinical_alert"])
        self.assertGreaterEqual(result["max_quarter_differential_ratio"], 1.15)
        self.assertIn("FL", result["affected_quarters"])

    def test_clinical_mastitis(self):
        sample = {
            "electrical_conductivity": 6.8,
            "quarter_conductivities": {"FL": 7.2, "FR": 4.5, "RL": 5.0, "RR": 4.8},
            "ph_level": 7.10,
            "scc_estimate": 850_000,
            "temperature_c": 39.8,
            "optical_density": 0.58
        }
        result = analyze_milk_sample(sample)
        self.assertEqual(result["risk_level"], "clinical_alert")
        self.assertGreaterEqual(result["risk_score"], 60)
        self.assertTrue(any("Quarter Asymmetry" in a["factor"] for a in result["anomaly_factors"]))

    def test_invalid_input_validation(self):
        invalid_sample = {
            "electrical_conductivity": -2.0,  # Impossible negative
            "ph_level": 14.5,                 # Beyond chemical scale
            "scc_estimate": -500              # Negative count
        }
        errors = validate_screening_input(invalid_sample)
        self.assertGreaterEqual(len(errors), 3)


if __name__ == "__main__":
    unittest.main()
