export type SupportedLanguage = 'en' | 'hi' | 'mr' | 'gu' | 'pa';

export interface Translations {
  appName: string;
  tagline: string;
  dashboard: string;
  animals: string;
  milkTesting: string;
  aiRiskAnalysis: string;
  alerts: string;
  reports: string;
  farmMap: string;
  devices: string;
  settings: string;
  totalHerd: string;
  screenedToday: string;
  requiringFollowUp: string;
  healthy: string;
  subclinical: string;
  clinical: string;
  inRecovery: string;
  conductScreening: string;
  registerAnimal: string;
  reviewAlerts: string;
  riskGauge: string;
  nodusExecution: string;
  recentScreenings: string;
  quarterSymmetry: string;
  somaticCellProxy: string;
  electricalConductivity: string;
  logout: string;
  login: string;
  signUp: string;
  assistant: string;
}

export const translations: Record<SupportedLanguage, Translations> = {
  en: {
    appName: 'MammarySentinel',
    tagline: 'Veterinary Dairy-Health & Early Mastitis Screening Platform',
    dashboard: 'Dashboard',
    animals: 'Herd Inventory',
    milkTesting: 'Milk Screening',
    aiRiskAnalysis: 'Risk Analytics',
    alerts: 'Clinical Alerts',
    reports: 'Audit Reports',
    farmMap: 'Barn Map',
    devices: 'Sensors & Hardware',
    settings: 'Settings & Farm Profile',
    totalHerd: 'Registered Animals',
    screenedToday: 'Screened Today',
    requiringFollowUp: 'Requires Follow-up',
    healthy: 'Healthy Baseline',
    subclinical: 'Subclinical Suspect',
    clinical: 'Clinical Alert',
    inRecovery: 'In Recovery',
    conductScreening: 'Record Screening',
    registerAnimal: 'Register Animal',
    reviewAlerts: 'Review Alerts',
    riskGauge: 'Mastitis Risk Index',
    nodusExecution: 'Nodus Compute Engine',
    recentScreenings: 'Recent Screenings',
    quarterSymmetry: 'Quarter Differential Ratio',
    somaticCellProxy: 'Somatic Cell Proxy (cells/mL)',
    electricalConductivity: 'Conductivity (mS/cm)',
    logout: 'Sign Out',
    login: 'Sign In',
    signUp: 'Create Account',
    assistant: 'Veterinary AI Assistant'
  },
  hi: {
    appName: 'मेमरी सेंटिनल',
    tagline: 'दुग्ध पशु स्वास्थ्य एवं प्रारंभिक थनैला (मैस्टाइटिस) जांच प्रणाली',
    dashboard: 'डैशबोर्ड',
    animals: 'पशु सूची',
    milkTesting: 'दूध जांच (स्क्रीनिंग)',
    aiRiskAnalysis: 'जोखिम विश्लेषण',
    alerts: 'चिकित्सीय अलर्ट',
    reports: 'रिपोर्ट एवं ऑडिट',
    farmMap: 'फार्म का नक्शा',
    devices: 'हार्डवेयर व सेंसर',
    settings: 'सेटिंग्स व प्रोफाइल',
    totalHerd: 'पंजीकृत पशु',
    screenedToday: 'आज की जांच',
    requiringFollowUp: 'निगरानी आवश्यक',
    healthy: 'स्वस्थ',
    subclinical: 'संभावित सबक्लिनिकल',
    clinical: 'गंभीर थनैला चेतावनी',
    inRecovery: 'सुधार की स्थिति',
    conductScreening: 'जांच दर्ज करें',
    registerAnimal: 'नया पशु जोड़ें',
    reviewAlerts: 'अलर्ट देखें',
    riskGauge: 'मैस्टाइटिस जोखिम सूचकांक',
    nodusExecution: 'नोडस कंप्यूट इंजन',
    recentScreenings: 'हाल की जांचें',
    quarterSymmetry: 'क्वार्टर अंतर अनुपात',
    somaticCellProxy: 'सोमैटिक सेल काउंट (SCC)',
    electricalConductivity: 'विद्युत चालकता (mS/cm)',
    logout: 'लॉग आउट',
    login: 'लॉग इन',
    signUp: 'खाता बनाएं',
    assistant: 'पशु चिकित्सा एआई सहायक'
  },
  mr: {
    appName: 'गोधारा',
    tagline: 'दुग्ध व्यवसाय आरोग्य व स्तनदाह (मॅस्टायटिस) तपासणी प्रणाली',
    dashboard: 'डॅशबोर्ड',
    animals: 'जनावरांची यादी',
    milkTesting: 'दूध तपासणी',
    aiRiskAnalysis: 'जोखीम विश्लेषण',
    alerts: 'सतर्कता सूचना',
    reports: 'तपासणी अहवाल',
    farmMap: 'गोठा नकाशा',
    devices: 'सेन्सर्स व उपकरणे',
    settings: 'सेटिंग्ज',
    totalHerd: 'एकूण जनावरे',
    screenedToday: 'आज तपासणी झालेले',
    requiringFollowUp: 'विशेष लक्ष आवश्यक',
    healthy: 'निरोगी',
    subclinical: 'संभाव्य सौम्य लक्षणे',
    clinical: 'तीव्र स्तनदाह',
    inRecovery: 'उपचाराधीन',
    conductScreening: 'तपासणी नोंदवा',
    registerAnimal: 'नवीन जनावर जोडा',
    reviewAlerts: 'सूचना तपासा',
    riskGauge: 'जोखीम निर्देशांक',
    nodusExecution: 'नोडस कम्प्युट इंजिन',
    recentScreenings: 'नुकत्याच झालेल्या तपासण्या',
    quarterSymmetry: 'कास फरक गुणोत्तर',
    somaticCellProxy: 'सोमॅटिक सेल संख्या',
    electricalConductivity: 'विद्युत वाहकता',
    logout: 'बाहेर पडा',
    login: 'प्रवेश करा',
    signUp: 'नोंदणी करा',
    assistant: 'पशुवैद्यकीय एआय सहाय्यक'
  },
  gu: {
    appName: 'ગૌધારા',
    tagline: 'ડેરી પશુ આરોગ્ય અને મસ્ટાઇટિસ સ્ક્રીનીંગ પ્લેટફોર્મ',
    dashboard: 'ડેશબોર્ડ',
    animals: 'પશુ યાદી',
    milkTesting: 'દૂધ પરીક્ષણ',
    aiRiskAnalysis: 'જોખમ વિશ્લેષણ',
    alerts: 'ચેતવણીઓ',
    reports: 'રિપોર્ટ્સ',
    farmMap: 'તબેલાનો નકશો',
    devices: 'હાર્ડવેર સેન્સર્સ',
    settings: 'સેટિંગ્સ',
    totalHerd: 'કુલ પશુઓ',
    screenedToday: 'આજનું પરીક્ષણ',
    requiringFollowUp: 'ધ્યાન જરૂરી',
    healthy: 'તંદુરસ્ત',
    subclinical: 'પ્રારંભિક શંકાસ્પદ',
    clinical: 'તીવ્ર મસ્ટાઇટિસ',
    inRecovery: 'રિકવરી હેઠળ',
    conductScreening: 'પરીક્ષણ કરો',
    registerAnimal: 'પશુ ઉમેરો',
    reviewAlerts: 'ચેતવણી જુઓ',
    riskGauge: 'જોખમ ઇન્ડેક્સ',
    nodusExecution: 'નોડસ કમ્પ્યુટ',
    recentScreenings: 'તાજેતરના પરીક્ષણો',
    quarterSymmetry: 'ક્વાર્ટર ગુણોત્તર',
    somaticCellProxy: 'સોમેટિક સેલ કાઉન્ટ',
    electricalConductivity: 'ઇલેક્ટ્રિકલ કંડક્ટિવિટી',
    logout: 'લૉગ આઉટ',
    login: 'પ્રવેશ કરો',
    signUp: 'ખાતું બનાવો',
    assistant: 'પશુચિકિત્સક એઆઈ સહાયક'
  },
  pa: {
    appName: 'ਗਊਧਾਰਾ',
    tagline: 'ਡੇਅਰੀ ਪਸ਼ੂ ਸਿਹਤ ਅਤੇ ਮਸਟਾਈਟਿਸ ਸਕ੍ਰੀਨਿੰਗ ਪਲੇਟਫਾਰਮ',
    dashboard: 'ਡੈਸ਼ਬੋਰਡ',
    animals: 'ਪਸ਼ੂਆਂ ਦੀ ਸੂਚੀ',
    milkTesting: 'ਦੁੱਧ ਦੀ ਜਾਂਚ',
    aiRiskAnalysis: 'ਜੋਖਮ ਵਿਸ਼ਲੇਸ਼ਣ',
    alerts: 'ਚੇਤਾਵਨੀਆਂ',
    reports: 'ਰਿਪੋਰਟਾਂ',
    farmMap: 'ਫਾਰਮ ਦਾ ਨਕਸ਼ਾ',
    devices: 'ਹਾਰਡਵੇਅਰ ਸੈਂਸਰ',
    settings: 'ਸੈਟਿੰਗਾਂ',
    totalHerd: 'ਕੁੱਲ ਪਸ਼ੂ',
    screenedToday: 'ਅੱਜ ਦੀ ਜਾਂਚ',
    requiringFollowUp: 'ਨਿਗਰਾਨੀ ਦੀ ਲੋੜ',
    healthy: 'ਤੰਦਰੁਸਤ',
    subclinical: 'ਸ਼ੱਕੀ ਮਸਟਾਈਟਿਸ',
    clinical: 'ਗੰਭੀਰ ਮਸਟਾਈਟਿਸ',
    inRecovery: 'ਸੁਧਾਰ ਅਧੀਨ',
    conductScreening: 'ਜਾਂਚ ਦਰਜ ਕਰੋ',
    registerAnimal: 'ਪਸ਼ੂ ਸ਼ਾਮਲ ਕਰੋ',
    reviewAlerts: 'ਚੇਤਾਵਨੀਆਂ ਵੇਖੋ',
    riskGauge: 'ਜੋਖਮ ਇੰਡੈਕਸ',
    nodusExecution: 'ਨੋਡਸ ਕੰਪਿਊਟ',
    recentScreenings: 'ਹਾਲੀਆ ਜਾਂਚਾਂ',
    quarterSymmetry: 'ਕੁਆਰਟਰ ਅੰਤਰ',
    somaticCellProxy: 'ਸੋਮੈਟਿਕ ਸੈੱਲ ਕਾਊਂਟ',
    electricalConductivity: 'ਕੰਡਕਟੀਵਿਟੀ',
    logout: 'ਲਾਗ ਆਉਟ',
    login: 'ਲਾਗ ਇਨ',
    signUp: 'ਖਾਤਾ ਬਣਾਓ',
    assistant: 'ਵੈਟਰਨਰੀ ਏਆਈ ਸਹਾਇਕ'
  }
};
