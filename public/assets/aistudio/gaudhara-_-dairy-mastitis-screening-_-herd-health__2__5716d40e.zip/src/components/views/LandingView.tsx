import React from 'react';
import { 
  ShieldCheck, 
  Activity, 
  Cpu, 
  Database, 
  ArrowRight, 
  CheckCircle2, 
  Microscope, 
  AlertTriangle,
  FileText,
  Layers,
  ChevronRight,
  TrendingDown,
  Check,
  Stethoscope
} from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

interface LandingViewProps {
  onLoginClick: () => void;
  onSignUpClick: () => void;
  onExploreDemo: () => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onLoginClick,
  onSignUpClick,
  onExploreDemo,
}) => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-[#F8F9F8] text-[#19231D]">
      {/* Top Navigation */}
      <header className="border-b border-[#E5E7E5] bg-white sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded bg-[#1B4332] text-white flex items-center justify-center font-bold text-sm">
              MS
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg text-[#143D2B]">MammarySentinel</span>
                <span className="hidden sm:inline-block text-[10px] font-semibold text-[#52796F] border border-[#CBD5CD] px-1.5 py-0.2 rounded uppercase">
                  IIT Guwahati Demo
                </span>
              </div>
              <span className="hidden md:block text-[11px] text-[#64748B] leading-none">
                Dairy Health & Mastitis Screening
              </span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={onExploreDemo}
              className="text-xs font-semibold text-[#1B4332] hover:text-[#0F291E] px-3.5 py-2 rounded border border-[#1B4332]/40 bg-[#F1F5F3] hover:bg-[#E5ECE8] transition-colors"
            >
              Launch Live Hackathon Demo →
            </button>
            <button
              onClick={onLoginClick}
              className="text-xs font-semibold text-[#334155] hover:text-[#0F172A] px-3 py-2"
            >
              {t.login}
            </button>
            <button
              onClick={onSignUpClick}
              className="text-xs font-semibold text-white bg-[#1B4332] hover:bg-[#143427] px-4 py-2 rounded shadow-xs"
            >
              {t.signUp}
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 md:py-24 border-b border-[#E5E7E5] bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#1B4332] uppercase tracking-wider mb-4">
              <span>Veterinary Agritech</span>
              <span aria-hidden="true">·</span>
              <span>Subclinical Mastitis Screening</span>
              <span aria-hidden="true">·</span>
              <span>IIT Guwahati Hackathon 2026</span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-[#0F172A] leading-tight">
              Early Bovine Mastitis Screening Before Milk Loss & Tissue Damage
            </h1>

            <p className="mt-5 text-base sm:text-lg text-[#475569] leading-relaxed">
              MammarySentinel combines four-quarter electrical conductivity sensing, somatic cell proxies, 
              and ISFET pH tracking with an autonomous diagnostic engine to identify subclinical mastitis 
              <strong> 7 to 10 days before visible clinical symptoms appear</strong>.
            </p>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                onClick={onExploreDemo}
                className="px-6 py-3 text-sm font-semibold text-white bg-[#1B4332] hover:bg-[#143427] rounded-md shadow-xs flex items-center gap-2"
              >
                <span>Enter Operator Console</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={onSignUpClick}
                className="px-5 py-3 text-sm font-semibold text-[#1B4332] bg-[#F1F5F3] hover:bg-[#E5ECE8] border border-[#CBD5CD] rounded-md"
              >
                Register Dairy Farm
              </button>
            </div>

            <div className="mt-8 pt-6 border-t border-[#E2E8F0] grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs text-[#64748B]">
              <div>
                <strong className="block text-sm font-bold text-[#0F172A]">₹7,000+ Crore</strong>
                <span>Annual Indian dairy loss</span>
              </div>
              <div>
                <strong className="block text-sm font-bold text-[#0F172A]">15% Differential</strong>
                <span>Inter-quarter disparity threshold</span>
              </div>
              <div>
                <strong className="block text-sm font-bold text-[#0F172A]">4 Quarters</strong>
                <span>Independent FL, FR, RL, RR testing</span>
              </div>
              <div>
                <strong className="block text-sm font-bold text-[#0F172A]">7–10 Days Early</strong>
                <span>Before visual milk clot formation</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Real Clinical Problem Breakdown */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-b border-[#E5E7E5]">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold text-[#1B4332] uppercase tracking-wider">
            Clinical Problem Statement
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0F172A] mt-1">
            Why Traditional Dairy Monitoring Fails
          </h2>
          <p className="mt-3 text-sm text-[#475569]">
            Over 80% of mastitis in Indian dairy herds is subclinical: cows produce milk that looks completely normal to the naked eye while internal udder tissue suffers progressive damage.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#FEE2E2] text-[#DC2626] flex items-center justify-center font-bold">
              <TrendingDown className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Hidden Milk Yield Depression
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              Subclinical inflammation causes 15% to 25% yield drops per cow per lactation. Because the milk looks white and normal, farmers continue milking without realizing secretory cells are failing.
            </p>
          </div>

          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#FEF3C7] text-[#D97706] flex items-center justify-center font-bold">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              The Subjectivity of CMT Strips
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              The California Mastitis Test (CMT) requires subjective visual interpretation of gel viscosity. On a commercial 200-head dairy or smallholder co-op, daily CMT testing is impractical, labor-intensive, and prone to error.
            </p>
          </div>

          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#F1F5F3] text-[#1B4332] flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Irreversible Alveolar Fibrosis
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              By the time clinical symptoms (heat, swelling, flakes) emerge, secretory epithelial tissue has developed permanent fibrosis. Early screening preserves glandular integrity and reduces antibiotic usage by &gt;60%.
            </p>
          </div>
        </div>
      </section>

      {/* The MammarySentinel 3-Pillar Solution */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold text-[#1B4332] uppercase tracking-wider">
            Scientific Foundation
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0F172A] mt-1">
            Grounded in International Dairy Federation (IDF) Standards
          </h2>
          <p className="mt-3 text-sm text-[#475569]">
            MammarySentinel replaces guesswork with physical telemetry based on IDF Bulletin 338 and National Mastitis Council (NMC) guidelines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#F1F5F3] text-[#1B4332] flex items-center justify-center">
              <Activity className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Quarter Differential Ratio (QDR)
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              Bovine mastitis almost universally begins in a single quarter. Comparing electrical conductivity across all four quarters detects tight-junction destruction with &gt;92% sensitivity.
            </p>
            <div className="text-xs text-[#64748B] pt-2 font-mono border-t border-[#E2E8F0]">
              Rule: QDR = max(EC) / min(EC) &gt; 1.15x
            </div>
          </div>

          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#F1F5F3] text-[#1B4332] flex items-center justify-center">
              <Microscope className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Somatic Cell Count Proxy
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              Leukocytic migration (neutrophils and macrophages) into milk cisterns causes rapid turbidity changes. MammarySentinel tracks somatic indices across healthy (&lt;200k), subclinical (200k–500k), and acute (&gt;500k) ranges.
            </p>
            <div className="text-xs text-[#64748B] pt-2 font-mono border-t border-[#E2E8F0]">
              Sensor: Dual-wavelength optical density
            </div>
          </div>

          <div className="p-6 bg-white rounded-lg border border-[#E2E8F0] space-y-3">
            <div className="w-10 h-10 rounded-md bg-[#F1F5F3] text-[#1B4332] flex items-center justify-center">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="font-bold text-base text-[#0F172A]">
              Autonomous Edge Engine
            </h3>
            <p className="text-xs text-[#475569] leading-relaxed">
              Operates natively on field tablets or barn computers in &lt;1 ms with zero external cloud dependencies. Supports optional cluster execution via Nodus Compute when API credentials are provided.
            </p>
            <div className="text-xs text-[#64748B] pt-2 font-mono border-t border-[#E2E8F0]">
              Engine: Deterministic Python v2.4
            </div>
          </div>
        </div>
      </section>

      {/* Pre-Loaded Demonstration Test Cases */}
      <section className="bg-white py-14 border-t border-b border-[#E5E7E5]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-8">
            <span className="text-xs font-bold text-[#1B4332] uppercase tracking-wider">
              Live Hackathon Test Bench
            </span>
            <h3 className="text-xl sm:text-2xl font-bold text-[#0F172A] mt-1">
              Demonstration Animals Pre-Configured in System
            </h3>
            <p className="text-xs text-[#64748B] mt-1">
              The platform includes real livestock profiles with complete telemetry history ready for live demonstration:
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
            <div className="p-4 rounded-lg border border-[#E2E8F0] bg-[#F8FAF9] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#0F172A]">Ganga (GIR-104)</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#DCFCE7] text-[#166534]">
                  Healthy Baseline
                </span>
              </div>
              <p className="text-[#64748B]">Breed: Gir (Indigenous Zebu) · Parity 2 · Early Lactation</p>
              <div className="font-mono text-[#334155] text-[11px] pt-1 border-t border-[#E2E8F0]">
                All quarters balanced: 4.5 mS/cm · SCC: 120,000 · QDR: 1.02x
              </div>
            </div>

            <div className="p-4 rounded-lg border border-[#FDE68A] bg-[#FFFDF5] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#0F172A]">Kamdhenu (SAH-208)</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#FEF3C7] text-[#92400E]">
                  Subclinical Suspect
                </span>
              </div>
              <p className="text-[#64748B]">Breed: Sahiwal · Parity 3 · Mid Lactation</p>
              <div className="font-mono text-[#92400E] text-[11px] pt-1 border-t border-[#FDE68A]">
                FL elevated: 5.90 mS/cm vs 4.60 mS/cm · QDR: 1.28x (Flagged)
              </div>
            </div>

            <div className="p-4 rounded-lg border border-[#FCA5A5] bg-[#FFFBFB] space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#0F172A]">Lakshmi (HFX-405)</span>
                <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-[#FEE2E2] text-[#991B1B]">
                  Acute Clinical Alert
                </span>
              </div>
              <p className="text-[#64748B]">Breed: HF Cross (Frieswal) · Parity 1 · Isolation Pen</p>
              <div className="font-mono text-[#991B1B] text-[11px] pt-1 border-t border-[#FCA5A5]">
                RL quarter: 7.20 mS/cm · pH: 7.15 · SCC: 850,000 (Quarantine)
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Footer Banner */}
      <section className="bg-[#1B4332] text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-xl sm:text-2xl font-bold">
              Ready for the IIT Guwahati Demonstration?
            </h3>
            <p className="text-sm text-[#A3B899] mt-1">
              One-click entry to the full operator dashboard with all animal profiles, screening chamber, and sensor diagnostics.
            </p>
          </div>
          <button
            onClick={onExploreDemo}
            className="px-6 py-3 bg-white text-[#1B4332] hover:bg-[#F8FAF9] font-bold text-sm rounded-md shadow-sm shrink-0"
          >
            Launch Veterinary Console Now
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E5E7E5] bg-white py-8 text-xs text-[#64748B]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>© 2026 MammarySentinel. Developed for dairy animal welfare & field mastitis screening.</p>
          <div className="flex items-center gap-4">
            <span className="font-medium text-[#1B4332]">IIT Guwahati Hackathon Edition</span>
            <span>·</span>
            <span>IDF Standard 338</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
