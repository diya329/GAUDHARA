import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Download, 
  Printer, 
  Calendar, 
  CheckCircle2, 
  AlertTriangle, 
  Share2,
  Table
} from 'lucide-react';
import type { Animal, ScreeningRecord, FarmStats } from '../../types';
import { api } from '../../services/api';

export const ReportsView: React.FC = () => {
  const [stats, setStats] = useState<FarmStats | null>(null);
  const [animals, setAnimals] = useState<Animal[]>([]);
  const [screenings, setScreenings] = useState<ScreeningRecord[]>([]);
  const [reportDate, setReportDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    Promise.all([api.getStats(), api.getAnimals(), api.getScreenings()]).then(
      ([st, an, sc]) => {
        setStats(st);
        setAnimals(an);
        setScreenings(sc);
      }
    );
  }, []);

  const exportCSV = () => {
    if (screenings.length === 0) return;
    const headers = [
      'Screening ID',
      'Animal Tag',
      'Animal Name',
      'Quarter',
      'Conductivity (mS/cm)',
      'Somatic Cell Proxy',
      'pH',
      'Risk Score',
      'Risk Level',
      'Compute Provider',
      'Date Time'
    ];

    const rows = screenings.map((s) => [
      s.id,
      s.animal_tag,
      `"${s.animal_name}"`,
      s.quarter,
      s.electrical_conductivity,
      s.scc_estimate,
      s.ph_level,
      s.compute_result.risk_score,
      s.compute_result.risk_level,
      s.compute_result.provider,
      s.screened_at
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `MammarySentinel_Mastitis_Audit_${reportDate}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#E2E8F0] pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-[#0F172A] tracking-tight">
            Veterinary Audit Reports & Herd Compliance
          </h1>
          <p className="text-xs text-[#64748B] mt-0.5">
            Exportable records for dairy cooperatives, bulk milk testing, and veterinary health audits.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="px-3.5 py-1.5 text-xs font-semibold text-[#1B4332] bg-white border border-[#1B4332]/40 rounded hover:bg-[#F1F5F3] flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-1.5 text-xs font-semibold text-white bg-[#1B4332] hover:bg-[#143427] rounded shadow-xs flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Audit Sheet</span>
          </button>
        </div>
      </div>

      {/* Printable Audit Sheet Layout */}
      <div className="bg-white p-8 rounded-lg border border-[#E2E8F0] shadow-2xs space-y-6 printable-report">
        {/* Farm & Report Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#E2E8F0] pb-6">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="font-bold text-xl text-[#143D2B]">MammarySentinel Dairy Health</span>
              <span className="text-xs text-[#64748B] font-mono">| Mastitis Audit Certificate</span>
            </div>
            <p className="text-xs text-[#475569]">
              Farm Profile: MammarySentinel Herd Unit #4 · State Veterinary Council Registration #MH-VET-4820
            </p>
          </div>

          <div className="text-right text-xs text-[#64748B] font-mono">
            <div>Audit Date: <strong>{reportDate}</strong></div>
            <div>IIT Guwahati Demonstration Edition</div>
          </div>
        </div>

        {/* Audit Metric Summary Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div className="p-3 bg-[#F8FAF9] rounded border border-[#E2E8F0]">
            <span className="text-[#64748B] block">Total Milking Cows</span>
            <span className="text-lg font-bold font-mono text-[#0F172A]">{stats?.total_animals ?? 0}</span>
          </div>
          <div className="p-3 bg-[#F8FAF9] rounded border border-[#E2E8F0]">
            <span className="text-[#64748B] block">Healthy Herd Ratio</span>
            <span className="text-lg font-bold font-mono text-[#166534]">
              {stats?.total_animals 
                ? Math.round(((stats.healthy_count || 0) / stats.total_animals) * 100)
                : 0}%
            </span>
          </div>
          <div className="p-3 bg-[#F8FAF9] rounded border border-[#E2E8F0]">
            <span className="text-[#64748B] block">Subclinical Suspects</span>
            <span className="text-lg font-bold font-mono text-[#B45309]">{stats?.subclinical_count ?? 0}</span>
          </div>
          <div className="p-3 bg-[#F8FAF9] rounded border border-[#E2E8F0]">
            <span className="text-[#64748B] block">Clinical Cases Flagged</span>
            <span className="text-lg font-bold font-mono text-[#DC2626]">{stats?.clinical_count ?? 0}</span>
          </div>
        </div>

        {/* Herd Breakdown Table */}
        <div className="space-y-2">
          <h3 className="font-bold text-xs uppercase tracking-wider text-[#475569]">
            Herd Screening & Parity Registry
          </h3>

          <div className="border border-[#E2E8F0] rounded overflow-hidden">
            <table className="w-full text-xs text-left">
              <thead className="bg-[#F8FAF9] text-[#64748B] border-b border-[#E2E8F0]">
                <tr>
                  <th className="px-3 py-2">Tag ID</th>
                  <th className="px-3 py-2">Cow Name</th>
                  <th className="px-3 py-2">Breed</th>
                  <th className="px-3 py-2">Lactation Stage</th>
                  <th className="px-3 py-2">Daily Yield</th>
                  <th className="px-3 py-2">Current Mastitis Status</th>
                  <th className="px-3 py-2">Last Screened</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#E2E8F0]">
                {animals.map((a) => (
                  <tr key={a.id}>
                    <td className="px-3 py-2 font-mono font-bold text-[#0F172A]">{a.tag_id}</td>
                    <td className="px-3 py-2 font-medium">{a.name}</td>
                    <td className="px-3 py-2 text-[#475569]">{a.breed}</td>
                    <td className="px-3 py-2">{a.lactation_stage}</td>
                    <td className="px-3 py-2 font-mono">{a.avg_daily_yield_liters} L</td>
                    <td className="px-3 py-2">
                      <span className={`inline-block px-2 py-0.5 rounded text-[11px] font-semibold ${
                        a.status === 'healthy' ? 'bg-[#DCFCE7] text-[#166534]' :
                        a.status === 'subclinical_suspect' ? 'bg-[#FEF3C7] text-[#92400E]' :
                        a.status === 'clinical_alert' ? 'bg-[#FEE2E2] text-[#991B1B]' :
                        'bg-[#DBEAFE] text-[#1E40AF]'
                      }`}>
                        {a.status.replace('_', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-[#64748B]">
                      {a.last_screened_at ? new Date(a.last_screened_at).toLocaleDateString() : 'Never'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Veterinary Attestation */}
        <div className="pt-6 border-t border-[#E2E8F0] grid grid-cols-2 gap-8 text-xs text-[#64748B]">
          <div>
            <span className="block font-semibold text-[#0F172A] mb-8">
              Supervising Veterinary Officer:
            </span>
            <div className="border-b border-[#CBD5E1] w-48 mb-1" />
            <span>Dr. Sunita Sharma, B.V.Sc & A.H. (Reg: VCI-48102)</span>
          </div>

          <div className="text-right">
            <span className="block font-semibold text-[#0F172A] mb-8">
              Farm Management Attestation:
            </span>
            <div className="border-b border-[#CBD5E1] w-48 mb-1 ml-auto" />
            <span>Rajesh Patil (Lead Dairy Operations Manager)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
