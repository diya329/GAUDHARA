import React from 'react';
import { 
  LayoutDashboard, 
  FolderKanban, 
  FlaskConical, 
  LineChart, 
  Bell, 
  FileText, 
  History, 
  MapPin, 
  Cpu, 
  Settings,
  AlertTriangle,
  Stethoscope
} from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export type ActiveTab = 
  | 'dashboard' 
  | 'animals' 
  | 'milk_testing' 
  | 'assistant'
  | 'ai_risk' 
  | 'alerts' 
  | 'reports' 
  | 'history' 
  | 'farm_map' 
  | 'hardware' 
  | 'settings';

interface SidebarProps {
  currentTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  pendingAlertsCount?: number;
  isOpen?: boolean;
  onClose?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onSelectTab,
  pendingAlertsCount = 0,
  isOpen = false,
  onClose,
}) => {
  const { t } = useLanguage();

  const navigationItems = [
    { id: 'dashboard' as ActiveTab, label: t.dashboard, icon: LayoutDashboard },
    { id: 'animals' as ActiveTab, label: t.animals, icon: FolderKanban },
    { id: 'milk_testing' as ActiveTab, label: t.milkTesting, icon: FlaskConical },
    { id: 'assistant' as ActiveTab, label: t.assistant || 'Veterinary Assistant', icon: Stethoscope },
    { id: 'ai_risk' as ActiveTab, label: t.aiRiskAnalysis, icon: LineChart },
    { 
      id: 'alerts' as ActiveTab, 
      label: t.alerts, 
      icon: Bell, 
      badge: pendingAlertsCount > 0 ? pendingAlertsCount : undefined 
    },
    { id: 'reports' as ActiveTab, label: t.reports, icon: FileText },
    { id: 'history' as ActiveTab, label: 'Screening Logs', icon: History },
    { id: 'farm_map' as ActiveTab, label: t.farmMap, icon: MapPin },
    { id: 'hardware' as ActiveTab, label: t.devices, icon: Cpu },
    { id: 'settings' as ActiveTab, label: t.settings, icon: Settings },
  ];

  const handleSelect = (tab: ActiveTab) => {
    onSelectTab(tab);
    if (onClose) onClose();
  };

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          onClick={onClose}
          className="fixed inset-0 z-30 bg-black/40 lg:hidden"
          aria-hidden="true"
        />
      )}

      {/* Sidebar container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-30 w-64 bg-white border-r border-[#E2E8F0] transform transition-transform duration-200 ease-in-out lg:translate-x-0 lg:static lg:h-[calc(100vh-4rem)] flex flex-col justify-between ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="p-4 space-y-1 overflow-y-auto">
          <div className="text-[11px] font-semibold text-[#64748B] uppercase tracking-wider px-3 mb-2">
            Clinical Operations
          </div>

          {navigationItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => handleSelect(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md text-xs font-medium transition-colors text-left ${
                  isActive
                    ? 'bg-[#1B4332] text-white shadow-xs'
                    : 'text-[#334155] hover:bg-[#F8FAF9] hover:text-[#0F172A]'
                }`}
              >
                <div className="flex items-center gap-2.5 min-w-0">
                  <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-white' : 'text-[#64748B]'}`} />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge !== undefined && (
                  <span
                    className={`ml-2 px-1.5 py-0.5 rounded text-[10px] font-bold ${
                      isActive
                        ? 'bg-white text-[#1B4332]'
                        : 'bg-[#DC2626] text-white'
                    }`}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Farm info summary */}
        <div className="p-4 border-t border-[#E2E8F0] bg-[#F8FAF9] text-xs">
          <div className="text-[#0F172A] font-semibold truncate">
            MammarySentinel v2.4
          </div>
          <div className="text-[11px] text-[#64748B] mt-0.5">
            IIT Guwahati Hackathon Edition
          </div>
        </div>
      </aside>
    </>
  );
};
