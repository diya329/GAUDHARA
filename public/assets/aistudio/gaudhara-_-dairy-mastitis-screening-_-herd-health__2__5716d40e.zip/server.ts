import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { spawn } from 'child_process';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const portArgIndex = process.argv.indexOf('--port');
  const cliPort = portArgIndex !== -1 ? Number(process.argv[portArgIndex + 1]) : null;
  const PORT = cliPort || (process.env.PORT && process.env.PORT !== '8080' ? Number(process.env.PORT) : 3000);

  app.use(express.json({ limit: '10mb' }));

  // API Route: Nodus Compute / Local Rule-Engine Screening execution
  app.post('/api/screenings/compute', async (req, res) => {
    try {
      const sample = req.body;
      const jsonPayload = JSON.stringify(sample);

      // Execute Python screening module
      const pythonProcess = spawn('python3', [
        '-c',
        'import sys, json; from backend.main import process_screening_request; print(json.dumps(process_screening_request(json.loads(sys.stdin.read()))))'
      ], {
        env: {
          ...process.env,
          PYTHONPATH: __dirname,
        }
      });

      let stdout = '';
      let stderr = '';

      pythonProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      pythonProcess.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      pythonProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Python execution error:', stderr);
          return res.status(500).json({
            status: 'failed',
            error: 'Screening computation failed in python engine',
            details: stderr || 'Unknown execution failure'
          });
        }

        try {
          const result = JSON.parse(stdout.trim());
          return res.json(result);
        } catch (parseErr) {
          console.error('Failed to parse Python output:', stdout);
          return res.status(500).json({
            status: 'failed',
            error: 'Invalid computation output format',
            raw: stdout
          });
        }
      });

      pythonProcess.stdin.write(jsonPayload);
      pythonProcess.stdin.end();

    } catch (err: any) {
      console.error('Server error processing screening:', err);
      res.status(500).json({
        status: 'failed',
        error: err.message || 'Internal screening service failure'
      });
    }
  });

  // API Route: Nodus status & configuration
  app.get('/api/nodus/status', (_req, res) => {
    const hasKey = Boolean(process.env.NODUS_API_KEY && process.env.NODUS_API_KEY.trim().length > 0);
    res.json({
      configured: hasKey,
      provider: hasKey ? 'nodus_compute' : 'edge_engine',
      documentation_url: 'https://www.nodus-compute.ai/docs/',
      sdk_repo: 'https://github.com/Nodus-compute/Nodus-sdk-python',
      environment: process.env.NODE_ENV || 'development',
      message: hasKey 
        ? 'Nodus Compute credentials active. Workloads dispatched to remote GPU/CPU cloud cluster.'
        : 'Running in Autonomous Edge Engine Mode. Local veterinary physiological rule verification is active.'
    });
  });

  // API Route: Veterinary AI Assistant Chat endpoint
  app.post('/api/assistant/chat', async (req, res) => {
    try {
      const chatPayload = req.body;
      const jsonPayload = JSON.stringify(chatPayload);

      // Execute Python Chat Engine
      const pythonProcess = spawn('python3', [
        '-c',
        'import sys, json; from backend.main import process_chat_request; print(json.dumps(process_chat_request(json.loads(sys.stdin.read()))))'
      ], {
        env: {
          ...process.env,
          PYTHONPATH: __dirname,
        }
      });

      let stdout = '';
      let stderr = '';

      pythonProcess.stdout.on('data', (data) => {
        stdout += data.toString();
      });

      pythonProcess.stderr.on('data', (data) => {
        stderr += data.toString();
      });

      pythonProcess.on('close', (code) => {
        if (code !== 0) {
          console.error('Python assistant error:', stderr);
          return res.status(500).json({
            status: 'failed',
            error: 'Assistant processing failed in backend engine',
            reply: 'The veterinary assistant encountered an execution error. Please try again or consult on-site clinical staff.',
            is_fallback: true,
            provider: 'error_handler'
          });
        }

        try {
          const result = JSON.parse(stdout.trim());
          if (result.status === 'rate_limited') {
            return res.status(429).json(result);
          }
          if (result.status === 'error') {
            return res.status(400).json(result);
          }
          return res.json(result);
        } catch (parseErr) {
          console.error('Failed to parse Python assistant output:', stdout);
          return res.status(500).json({
            status: 'failed',
            error: 'Invalid assistant response format',
            reply: 'Invalid response format received from inference service.',
            is_fallback: true
          });
        }
      });

      pythonProcess.stdin.write(jsonPayload);
      pythonProcess.stdin.end();

    } catch (err: any) {
      console.error('Server error processing chat:', err);
      res.status(500).json({
        status: 'failed',
        error: err.message || 'Internal chat assistant failure',
        is_fallback: true
      });
    }
  });

  // API Route: Veterinary Assistant status & capability
  app.get('/api/assistant/status', (_req, res) => {
    const hasAgent37 = Boolean(process.env.AGENT37_API_KEY && process.env.AGENT37_API_KEY.trim().length > 0);
    const hasGemini = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
    const hasNodus = Boolean(process.env.NODUS_API_KEY && process.env.NODUS_API_KEY.trim().length > 0);
    
    let provider = 'edge_veterinary_knowledge_engine';
    if (hasAgent37) {
      provider = 'agent37_cloud';
    } else if (hasGemini) {
      provider = 'gemini-3.8-flash';
    } else if (hasNodus) {
      provider = 'nodus_compute';
    }
    
    res.json({
      status: 'online',
      active_provider: provider,
      is_fallback: !(hasAgent37 || hasGemini || hasNodus),
      model_name: hasAgent37 ? 'agent37-hermes' : (hasGemini ? 'gemini-3.8-flash' : 'rule_based_clinical_triage'),
      supported_languages: ['en', 'hi'],
      rate_limiting: '30 queries/minute',
      safety_disclaimer_mandatory: true,
      agent37: {
        configured: hasAgent37,
        is_connected: hasAgent37,
        instance_id: process.env.AGENT37_INSTANCE_ID || null,
        instance_url: process.env.AGENT37_INSTANCE_URL || null,
        provider: 'agent37_cloud'
      },
      message: hasAgent37
        ? 'Agent37 Cloud Hermes Veterinary Agent active on server'
        : (hasGemini 
            ? 'Gemini 3.8 Flash Veterinary AI Engine active on server'
            : 'Autonomous Veterinary Knowledge Engine active (transparent fallback mode)')
    });
  });

  // API Route: Dedicated Agent37 diagnostic status
  app.get('/api/agent37/status', (_req, res) => {
    const hasKey = Boolean(process.env.AGENT37_API_KEY && process.env.AGENT37_API_KEY.trim().length > 0);
    const instanceId = process.env.AGENT37_INSTANCE_ID || null;
    const instanceUrl = process.env.AGENT37_INSTANCE_URL || null;

    res.json({
      configured: hasKey,
      is_connected: hasKey,
      status: hasKey ? 'ready' : 'unconfigured',
      instance_id: instanceId,
      instance_url: instanceUrl,
      provider: 'agent37_cloud',
      template: 'agent37-hermes',
      documentation_url: 'https://www.agent37.com/docs',
      message: hasKey
        ? 'Agent37 Cloud credentials active on backend. Instance will process screening inquiries.'
        : 'AGENT37_API_KEY is not configured in backend environment.'
    });
  });

  // Health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'healthy',
      service: 'MammarySentinel Dairy Mastitis Screening Platform (IIT Guwahati Demonstration)',
      version: '2.4.0',
      timestamp: new Date().toISOString()
    });
  });

  // Vite integration
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`GauDhara server listening on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start GauDhara server:', err);
  process.exit(1);
});
