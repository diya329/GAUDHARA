# Nodus Compute Integration Guide — GauDhara Dairy Health

**Hackyard Build 2026 Official Integration Documentation**

This document describes the architecture, verification, test suite, and execution workflow of the Nodus Compute integration in GauDhara.

---

## 1. Official Documentation & References

- **Nodus Compute Documentation**: [https://www.nodus-compute.ai/docs/](https://www.nodus-compute.ai/docs/)
- **Python SDK Repository**: [https://github.com/Nodus-compute/Nodus-sdk-python](https://github.com/Nodus-compute/Nodus-sdk-python)
- **PyPI Package**: `nodus-compute` (`pip install nodus-compute`)

---

## 2. End-to-End Screening Architecture

```
[Dairy Farmer / Vet UI]
          │
          │ (1) Enters 4-Quarter EC, pH, SCC Proxy, Temp
          ▼
[GauDhara Express / FastAPI Service: /api/screenings/compute]
          │
          │ (2) Physical input validation & range sanity checks
          ├──────────────────────────┐
          │ (NODUS_API_KEY present)  │ (No Key / Dev Mode)
          ▼                          ▼
[Nodus Cloud Compute Cluster]   [Local Rule Verification Engine]
          │ (GPU/CPU Container)      │ (Deterministic Python Workload)
          │                          │
          │  - Inter-quarter ratio   │  - Inter-quarter ratio
          │  - Permeability index    │  - Permeability index
          │  - Somatic cell score    │  - Somatic cell score
          │                          │
          └──────────┬───────────────┘
                     │ (3) Return execution telemetry & score
                     ▼
       [GauDhara Dashboard & Telemetry Panel]
                     │
                     │ (4) Persist Screening Record & Alert
                     ▼
       [Supabase PostgreSQL RLS: screenings & alerts]
```

---

## 3. The Analysis Workload (`backend/workload.py`)

GauDhara's workload performs deterministic physiological calculations grounded in clinical veterinary science:

### Mathematical Markers Computed:
1. **Quarter Differential Ratio (QDR)**:
   $$\text{QDR} = \frac{\max(\text{EC}_{\text{FL}}, \text{EC}_{\text{FR}}, \text{EC}_{\text{RL}}, \text{EC}_{\text{RR}})}{\min(\text{EC}_{\text{FL}}, \text{EC}_{\text{FR}}, \text{EC}_{\text{RL}}, \text{EC}_{\text{RR}})}$$
   - $\text{QDR} < 1.15$: Normal bilateral symmetry.
   - $1.15 \le \text{QDR} < 1.25$: Early unilateral subclinical mastitis warning.
   - $\text{QDR} \ge 1.25$: High clinical alert for localized epithelial breakdown.

2. **Absolute Electrical Conductivity**:
   - Normal: $3.8 - 5.6\,\text{mS/cm}$.
   - Subclinical threshold: $5.8\,\text{mS/cm}$.
   - Clinical threshold: $6.4\,\text{mS/cm}$.

3. **Somatic Cell Count (SCC) Proxy**:
   - Healthy: $<200,000\,\text{cells/mL}$.
   - Subclinical: $200,000 - 500,000\,\text{cells/mL}$.
   - Clinical: $>500,000\,\text{cells/mL}$.

4. **Potentiometric pH Shift**:
   - Alkaline shift ($>6.90$): Serum leakage into milk cisterns.
   - Acidic shift ($<6.40$): Coliform bacterial fermentation.

---

## 4. Execution Evidence in the User Interface

The screening results panel in GauDhara displays verifiable execution telemetry:
- **Execution Provider**: `Nodus Cloud Compute` vs `Local Rule Verification Engine`.
- **Execution ID**: Real job ID returned by the service.
- **Latency (ms)**: High-resolution timing of the execution.
- **Timestamp**: UTC submission and completion timestamps.
- **Identified Anomaly Factors**: Transparent breakdown of which physiological thresholds were exceeded.
- **Veterinary Action Protocol**: Immediate recommendations (e.g. CMT verification, cluster disinfection, pipeline diversion).
- **Raw JSON Payload Inspector**: Full expandable debug view.

---

## 5. Automated Tests & Repeatable Smoke Test

### Running the Python Unit Tests:
```bash
python3 -m unittest backend/tests/test_screening.py
```
Expected output:
```text
....
----------------------------------------------------------------------
Ran 4 tests in 0.000s

OK
```

### Direct CLI Workload Verification:
You can verify the workload via stdin:
```bash
echo '{"electrical_conductivity": 6.2, "ph_level": 6.95, "scc_estimate": 650000, "quarter_conductivities": {"FL": 6.2, "FR": 4.5, "RL": 4.6, "RR": 4.7}}' | python3 backend/workload.py
```

---

## 6. Security and Credentials

- `NODUS_API_KEY` is **strictly server-side**. It is never exposed in client code or with `VITE_` prefixes.
- In production, configure `NODUS_API_KEY` via your container environment variables or server secret manager.
- If `NODUS_API_KEY` is not provided, GauDhara runs in transparent **Local Rule Verification Mode** and clearly labels it in the UI, never manufacturing fake job executions.
